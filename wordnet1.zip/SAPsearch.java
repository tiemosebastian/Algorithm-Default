public class SAPsearch {
	private final short V=1;
	private final short W=-1;
	private final int inf=Integer.MAX_VALUE;
	private int max;
	private pnt ref[];
	private int ancestor=-1;
	private final Digraph G;
	/*********************************************************************************
	 * public methods 																				*
	 ********************************************************************************/
	
	/**
	 * Initiate instance of class
	 * @param G
	 */
	public SAPsearch(Digraph G){
		if(G==null) throw new NullPointerException();
		ref = new pnt[G.V()];
		this.G = new Digraph(G);
	}
	/**
	 * returns the ancestor from the last search.
	 * @return
	 */
	public int ancestor(){
		return ancestor;
	}
	/**
	 * returns the length of ths SAP from the last search
	 * @return
	 */
	public int length(){
		if(max==inf) return -1;
		return max;
	}
	/**Search Digraph for Shortest Ancestral Path SAP between the sets of point v in vs{} and w inws{}. 
	 * Method: enqueue points in vs and ws and do an alternating Breadth First Search
	 * if visited check, by which(if v finds w or vis-versa an SAP is found)
	 * Note: R keeps track of the values that were changed, and empties them after running.
	 * in order to efficiently implement many searches. 
	 * @param vs
	 * @param ws
	 */
	public void search(Iterable<Integer> vs, Iterable<Integer> ws){
		for(int v:vs){
			for(int w:ws){
				if(v==w){
					max=0;
					ancestor=v;
					return;
				}
			}
		}
		Queue<Integer> Q = new Queue<Integer>();
		Bag<Integer> R = new Bag<Integer>();
		for(int v:vs){
			ref[v]=new pnt(V,0);
			Q.enqueue(v);
			R.add(v);
		}
		for( int w:ws){
			ref[w]=new pnt(W,0);
			Q.enqueue(w);
			R.add(w);
		}
		max=inf;
		ancestor=-1;
		testQ(Q,R);
		refresh(R);
	}
	/**
	 * Search Digraph for Shortest Ancestral Path SAP between v,w. 
	 * Method: enqueue point v and w and do an alternating Breadth First Search
	 * if visited check, by which(if v finds w or vis-versa an SAP is found)
	 * Note: R keeps track of the values that were changed, and empties them after running.
	 * in order to efficiently implement many searches. 
	 * @param v
	 * @param w
	 */
	public void search(int v, int w){
		if(v==w) {
			max=0;
			ancestor=v;
			return;
		}
		Queue<Integer> Q = new Queue<Integer>();
		Bag<Integer> R = new Bag<Integer>();
		ref[v]=new pnt(V,0);
		ref[w]=new pnt(W,0);
		Q.enqueue(v);
		Q.enqueue(w);
		R.add(v);
		R.add(w);
		max=inf;
		ancestor=-1;
		testQ(Q,R);
		refresh(R);
	}
	/*********************************************************************************
	 * 	private methods																*
	 ********************************************************************************/
	/**

	 * Method to test whether the iterable version of the sapsearch return the correct result
	 * (As determined by the non-iterable search.
	 * @param vs
	 * @param ws
	 * @return
	 */
	/*private boolean testiter( Iterable<Integer> vs, Iterable<Integer> ws){
		int min=inf;
		for(int v:vs){
			for(int w:ws){
				search(v,w);
				if(min>max) min=this.max;
			}
		}
		search(vs,ws);
		if(min==max) return true; 
		StdOut.print("\nmin distances don't match in iterated single serach vs single iterated search!");
		StdOut.print("\n min: "+min+"\nmax: " + max);
		return false;
	}*/
	/** Runs the search called in search. Despite name not actually a test method.
	 * 
	 * @param Q
	 * @param R
	 */
	private void testQ(Queue<Integer> Q,Bag<Integer> R){
		int x;
		while(!Q.isEmpty()){
			x = Q.dequeue();
			if(ref[x].dist>max) break;
			for(int x1:G.adj(x)){
				if(visited(x1)){
					//if searchpaths(v and w) cross, check if shortest.
					if(ref[x].vw!=ref[x1].vw) {
						//if new shortest path save as ancestor
						if(max>ref[x1].dist+ref[x].dist+1){
							max=ref[x1].dist+ref[x].dist+1;
							//StdOut.print("\nmax: " +max);
							ancestor=x1;
							//StdOut.print("\nancestor: " +ancestor);
							//ancedg=x;
						}
						else continue;
					}
					else continue;
				}
				else{//mark new points, add to queue and cleanup queue
					ref[x1]=new pnt(ref[x].vw, ref[x].dist+1);//ref[x1].edge=x;	
					Q.enqueue(x1);
					R.add(x1);
				}
			}
		}
	}	
	/**
	 * undoes the array edits made by search
	 * @param R
	 */
	private void refresh(Iterable<Integer> R){
		for(int r:R){
			ref[r].vw=0;
			ref[r].vw=0;
		}
	}
	/**
	 * checks whether a point has been visited by the bfs
	 * @param v
	 * @return
	 */
	private boolean visited(int v){
		if(ref[v]==null) return false;
		if(ref[v].vw==0) return false;
		return true;
	}
	/**
	 * small point class to more concisely store data. 
	 * @author tiemo
	 *
	 */
	private class pnt{
		public short vw;
		public int dist;
		public pnt(short vw,int dist){
			this.vw=vw;
			this.dist=dist;
		}
	}
}
